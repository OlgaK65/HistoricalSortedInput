package com.shipment.historical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoricalApplicationTests {

	@Test
	void contextLoads() {		
	}
}
