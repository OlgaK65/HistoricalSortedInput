package com.shipment.historical.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public class ShipInterval {

	String shipment;
	Integer vessel;
	String sourcePort;
	String destinationPort;
	ShipDate start;
	ShipDate end;
}
