package com.shipment.historical.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public class ShipDate implements Comparable<ShipDate>{

	Integer day;
	Integer month;
	
	public ShipDate(String sDate) {
		int backslash =  sDate.indexOf('/');
		//String[] cDates = sDate.split("");
			
		if(backslash > 0) {
			String sDay = sDate.substring(0,backslash).trim();
			this.day = Integer.valueOf(sDay);
		
			String sMonth = sDate.substring(backslash+1, sDate.length()).trim();
			this.month = Integer.valueOf(sMonth);		
		}
	}
	
	public ShipDate(ShipDate sd) {
		this.day = sd.getDay();
		this.month = sd.getMonth();
	}
	
	@Override
	public int compareTo(ShipDate sd) {
		
	// we do not check year for this example 	
		if(this.month > sd.getMonth())
		  return 1;
		else {
		  if(this.month < sd.getMonth())	
			  return -1;
		  else {
			  if(this.day > sd.getDay())
				  return 1;
				else {
				  if(this.day < sd.getDay())	
					 return -1;
				  else
					 return 0; 
				}
		  }	  
		}
	}
}
