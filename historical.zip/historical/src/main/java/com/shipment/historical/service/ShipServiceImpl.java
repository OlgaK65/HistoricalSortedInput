package com.shipment.historical.service;


import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;

import com.shipment.historical.model.ShipInterval;
import com.shipment.historical.model.ShipPoint;

@Service
public class ShipServiceImpl implements ShipService {

	Map<Integer, List<ShipPoint>> shipMap = new HashMap<>();
	
	@Override
	public Set<Integer> getMapKeys(){
		return  shipMap.keySet();
	}
	
	@Override
	public void createMap(List<ShipInterval> shipIntervals, String start, String end){
		
		shipMap.clear();
		shipIntervals.forEach(si -> putShipPoint(si));
	}
	
	@Override
	public List<ShipPoint> getHistoricalAisData(int vessel, String start, String end) {
		return shipMap.get(vessel);		
	}

	private void putShipPoint(ShipInterval si)
// I mean in accordance to input data, points are sorted by (start, end)	
	{		 
		 Integer vessel = si.getVessel();
		 ShipPoint sp = new ShipPoint(vessel, si.getStart(),si.getEnd());
		 
		 List<ShipPoint> ll = shipMap.get(vessel);
		 if(ll == null) {	
			 ll = new LinkedList<>();
		     ll.add(sp);
		     shipMap.put(vessel, ll);
		 }
		 else {
			 int lSize = ll.size();
			 ShipPoint lastPoint = ll.get(lSize-1);
// continue current path of vessel			 
			 if(lastPoint.getEnd().compareTo(sp.getStart()) == 0) 
			   lastPoint.setEnd(sp.getEnd());
			 
// add new part of path			 
			 if(lastPoint.getEnd().compareTo(sp.getStart()) < 0) 
				ll.add(sp);
		 }
	 }
}
