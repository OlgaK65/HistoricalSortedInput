package com.shipment.historical.model;

import java.util.Comparator;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ShipPoint {
	Integer vessel;
	ShipDate start;
	ShipDate end;
	
	@JsonIgnore
	Comparator<ShipPoint> compShip = (s1,s2) -> {
		if(s1.getVessel() != s2.getVessel())
			return s1.getVessel() - s2.getVessel();
		
		if(s1.getStart() != s2.getStart())
			return s1.getStart().compareTo(s2.getStart());
		
		if(s1.getEnd() != s2.getEnd())
			return s1.getEnd().compareTo(s2.getEnd());
		
		return 0;
	};
	
	public ShipPoint(ShipPoint sp0, ShipPoint sp1){
		if(sp0 != null) {
			this.vessel = sp0.getVessel();
			this.start = sp0.getStart();
		}	
		
		if(sp1 != null)
			this.end = sp1.getEnd();		 
	}
	
	public ShipPoint(Integer vessel, ShipDate start, ShipDate end){
		this.vessel = vessel;
		this.start = new ShipDate(start);
		this.end = new ShipDate(end);
	}
}
